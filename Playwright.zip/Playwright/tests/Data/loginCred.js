export default  {
    'email':"natashamahawar@yopmail.com" ,
    "pwd":"1234"
} 